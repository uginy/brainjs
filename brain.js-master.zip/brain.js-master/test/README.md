# Tests

To run the tests in this directory, make sure you've installed the dev dependencies with this command from the top-level directory:

```
npm install
```

Then you can run all tests using `npm test`.

# Unit tests
Run the unit tests with:

```
npm test
```

See [package.json](../package.json) for more testing examples.
