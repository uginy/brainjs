export default function randomWeight() {
  return Math.random() * 0.4 - 0.2;
}